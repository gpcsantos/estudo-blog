# Blog

Este é o blog que foi criado no curso de Python de Luiz Otávio Miranda.
